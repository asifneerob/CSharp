﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Computer_Retail_Store
{
    public partial class ManagerEmployeeHome : Form
    {
        public ManagerEmployeeHome()
        {
            InitializeComponent();
        }

        private void ManagerHome_FormClosing(object sender, FormClosingEventArgs e)
        {
            Application.Exit();
        }

        private void logoutBtn_Click(object sender, EventArgs e)
        {
            new Login().Show();
            this.Hide();
        }

        private void customerInfoBtn_Click(object sender, EventArgs e)
        {
            new CustomerInfo().Show();
            this.Hide();
        }

        private void manageProductBtn_Click(object sender, EventArgs e)
        {
            new ManageProduct().Show();
            this.Hide();
        }

        private void productSoldBtn_Click(object sender, EventArgs e)
        {
            new SoldProduct().Show();
            this.Hide();
        }

        private void myInfoBtn_Click(object sender, EventArgs e)
        {
            new ManagerEmployeeInfo().Show();
            this.Hide();
        }

        private void cngPassBtn_Click(object sender, EventArgs e)
        {
            new ManagerChangePassword().Show();
            this.Hide();
        }

        private void employeeInfoBtn_Click(object sender, EventArgs e)
        {
            new ManagerSeeGeneralEmployeeInfo().Show();
            this.Hide();
        }
    }
}
