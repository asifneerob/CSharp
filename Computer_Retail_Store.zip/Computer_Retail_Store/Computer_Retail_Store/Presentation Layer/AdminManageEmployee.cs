﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Computer_Retail_Store.Business_Logic_Layer;

namespace Computer_Retail_Store
{
    public partial class AdminManageEmployee : Form
    {
        LogTypeInfo l = new LogTypeInfo();
        public AdminManageEmployee()
        {
            InitializeComponent();
        }

        private void OwnerManageEmployee_FormClosing(object sender, FormClosingEventArgs e)
        {
            Application.Exit();
        }

        private void logoutBtn_Click(object sender, EventArgs e)
        {
            new Login().Show();
            this.Hide();
        }

        private void backBtn_Click(object sender, EventArgs e)
        {
            new AdminHome().Show();
            this.Hide();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            int type;

            if (employeeRoleCB.Text == "General")
            {
                type = 3;
            }
            else
            {
                type = 2;
            }
            if (l.CreatePerson(int.Parse(employeeIdTB.Text),passTB.Text, type))
            {
                
                MessageBox.Show("Successfully Person Created");
            }
            else
            {
                MessageBox.Show("Error in creating");
            }
        }

        private void autoGenerateIdBtn_Click(object sender, EventArgs e)
        {
            Random r = new Random();
            employeeIdTB.Text = r.Next(1000, 8999).ToString();
        }
    }
}
