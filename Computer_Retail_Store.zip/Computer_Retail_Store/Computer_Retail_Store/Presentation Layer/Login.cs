﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Computer_Retail_Store.Business_Logic_Layer;
using Computer_Retail_Store.Data_Access_Layer;

namespace Computer_Retail_Store
{
    public partial class Login : Form
    {

        LogTypeInfo p = new LogTypeInfo();
        LoginInfo l = new LoginInfo();
        DataTable dt = new DataTable();
        DataAccess d = new DataAccess();
        public int type;
        public Login()
        {
            InitializeComponent();
        }

        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
            Application.Exit();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            l.UserId = int.Parse(textBox1.Text);
            l.Password = textBox2.Text;
            dt = d.login(l);
            if (dt.Rows.Count == 1)
            {
                type = int.Parse(dt.Rows[0][2].ToString());
                if (type == 1)
                {
                    new AdminHome(l.UserId).Show();
                    this.Hide();
                }
                else if (type == 2)
                {
                    new ManagerEmployeeHome().Show();
                    this.Hide();
                }
                else if (type == 3)
                {
                    new GeneralEmployeeHome().Show();
                    this.Hide();
                }
                else
                {
                    MessageBox.Show("UserID or Password is incorrect");
                }
            }
            else
            {
                MessageBox.Show("UserID or Password is incorrect");
            }

        }
    }
}
