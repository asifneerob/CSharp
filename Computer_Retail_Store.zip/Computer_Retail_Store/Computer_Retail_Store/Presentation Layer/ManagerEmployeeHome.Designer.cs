﻿namespace Computer_Retail_Store
{
    partial class ManagerEmployeeHome
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.logoutBtn = new System.Windows.Forms.Button();
            this.myInfoBtn = new System.Windows.Forms.Button();
            this.cngPassBtn = new System.Windows.Forms.Button();
            this.customerInfoBtn = new System.Windows.Forms.Button();
            this.manageProductBtn = new System.Windows.Forms.Button();
            this.productSoldBtn = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.employeeInfoBtn = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // logoutBtn
            // 
            this.logoutBtn.Location = new System.Drawing.Point(895, 12);
            this.logoutBtn.Name = "logoutBtn";
            this.logoutBtn.Size = new System.Drawing.Size(75, 33);
            this.logoutBtn.TabIndex = 0;
            this.logoutBtn.Text = "Logout";
            this.logoutBtn.UseVisualStyleBackColor = true;
            this.logoutBtn.Click += new System.EventHandler(this.logoutBtn_Click);
            // 
            // myInfoBtn
            // 
            this.myInfoBtn.Location = new System.Drawing.Point(225, 233);
            this.myInfoBtn.Name = "myInfoBtn";
            this.myInfoBtn.Size = new System.Drawing.Size(211, 47);
            this.myInfoBtn.TabIndex = 1;
            this.myInfoBtn.Text = "My Info";
            this.myInfoBtn.UseVisualStyleBackColor = true;
            this.myInfoBtn.Click += new System.EventHandler(this.myInfoBtn_Click);
            // 
            // cngPassBtn
            // 
            this.cngPassBtn.Location = new System.Drawing.Point(225, 286);
            this.cngPassBtn.Name = "cngPassBtn";
            this.cngPassBtn.Size = new System.Drawing.Size(211, 47);
            this.cngPassBtn.TabIndex = 3;
            this.cngPassBtn.Text = "Change Password";
            this.cngPassBtn.UseVisualStyleBackColor = true;
            this.cngPassBtn.Click += new System.EventHandler(this.cngPassBtn_Click);
            // 
            // customerInfoBtn
            // 
            this.customerInfoBtn.Location = new System.Drawing.Point(572, 286);
            this.customerInfoBtn.Name = "customerInfoBtn";
            this.customerInfoBtn.Size = new System.Drawing.Size(211, 47);
            this.customerInfoBtn.TabIndex = 4;
            this.customerInfoBtn.Text = "Customer Info";
            this.customerInfoBtn.UseVisualStyleBackColor = true;
            this.customerInfoBtn.Click += new System.EventHandler(this.customerInfoBtn_Click);
            // 
            // manageProductBtn
            // 
            this.manageProductBtn.Location = new System.Drawing.Point(572, 339);
            this.manageProductBtn.Name = "manageProductBtn";
            this.manageProductBtn.Size = new System.Drawing.Size(211, 47);
            this.manageProductBtn.TabIndex = 7;
            this.manageProductBtn.Text = "Manage Product";
            this.manageProductBtn.UseVisualStyleBackColor = true;
            this.manageProductBtn.Click += new System.EventHandler(this.manageProductBtn_Click);
            // 
            // productSoldBtn
            // 
            this.productSoldBtn.Location = new System.Drawing.Point(572, 392);
            this.productSoldBtn.Name = "productSoldBtn";
            this.productSoldBtn.Size = new System.Drawing.Size(211, 47);
            this.productSoldBtn.TabIndex = 8;
            this.productSoldBtn.Text = "Product SOLD";
            this.productSoldBtn.UseVisualStyleBackColor = true;
            this.productSoldBtn.Click += new System.EventHandler(this.productSoldBtn_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(470, 28);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(66, 17);
            this.label1.TabIndex = 9;
            this.label1.Text = "Welcome";
            // 
            // employeeInfoBtn
            // 
            this.employeeInfoBtn.Location = new System.Drawing.Point(572, 233);
            this.employeeInfoBtn.Name = "employeeInfoBtn";
            this.employeeInfoBtn.Size = new System.Drawing.Size(211, 47);
            this.employeeInfoBtn.TabIndex = 10;
            this.employeeInfoBtn.Text = "Employee Info";
            this.employeeInfoBtn.UseVisualStyleBackColor = true;
            this.employeeInfoBtn.Click += new System.EventHandler(this.employeeInfoBtn_Click);
            // 
            // ManagerEmployeeHome
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(982, 653);
            this.Controls.Add(this.employeeInfoBtn);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.productSoldBtn);
            this.Controls.Add(this.manageProductBtn);
            this.Controls.Add(this.customerInfoBtn);
            this.Controls.Add(this.cngPassBtn);
            this.Controls.Add(this.myInfoBtn);
            this.Controls.Add(this.logoutBtn);
            this.Name = "ManagerEmployeeHome";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "ManagerHome";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.ManagerHome_FormClosing);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button logoutBtn;
        private System.Windows.Forms.Button myInfoBtn;
        private System.Windows.Forms.Button cngPassBtn;
        private System.Windows.Forms.Button customerInfoBtn;
        private System.Windows.Forms.Button manageProductBtn;
        private System.Windows.Forms.Button productSoldBtn;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button employeeInfoBtn;
    }
}