﻿namespace Computer_Retail_Store
{
    partial class AdminManageEmployee
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.autoGeneratePassBtn = new System.Windows.Forms.Button();
            this.employeeSalaryTB = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.loadBtn = new System.Windows.Forms.Button();
            this.updateBtn = new System.Windows.Forms.Button();
            this.addNewBtn = new System.Windows.Forms.Button();
            this.backBtn = new System.Windows.Forms.Button();
            this.logoutBtn = new System.Windows.Forms.Button();
            this.employeeAddressTB = new System.Windows.Forms.TextBox();
            this.employeePhnNoTB1 = new System.Windows.Forms.TextBox();
            this.employeePhnNoTB2 = new System.Windows.Forms.TextBox();
            this.employeeNameTB = new System.Windows.Forms.TextBox();
            this.passTB = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.employeeIdTB = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.employeeRoleCB = new System.Windows.Forms.ComboBox();
            this.deleteBtn = new System.Windows.Forms.Button();
            this.autoGenerateIdBtn = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // autoGeneratePassBtn
            // 
            this.autoGeneratePassBtn.Location = new System.Drawing.Point(604, 208);
            this.autoGeneratePassBtn.Name = "autoGeneratePassBtn";
            this.autoGeneratePassBtn.Size = new System.Drawing.Size(146, 23);
            this.autoGeneratePassBtn.TabIndex = 44;
            this.autoGeneratePassBtn.Text = "Auto Generate Pass";
            this.autoGeneratePassBtn.UseVisualStyleBackColor = true;
            // 
            // employeeSalaryTB
            // 
            this.employeeSalaryTB.Location = new System.Drawing.Point(433, 350);
            this.employeeSalaryTB.Name = "employeeSalaryTB";
            this.employeeSalaryTB.Size = new System.Drawing.Size(139, 22);
            this.employeeSalaryTB.TabIndex = 43;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(358, 208);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(69, 17);
            this.label7.TabIndex = 42;
            this.label7.Text = "Password";
            // 
            // loadBtn
            // 
            this.loadBtn.Location = new System.Drawing.Point(604, 179);
            this.loadBtn.Name = "loadBtn";
            this.loadBtn.Size = new System.Drawing.Size(75, 23);
            this.loadBtn.TabIndex = 41;
            this.loadBtn.Text = "Load";
            this.loadBtn.UseVisualStyleBackColor = true;
            // 
            // updateBtn
            // 
            this.updateBtn.Location = new System.Drawing.Point(497, 404);
            this.updateBtn.Name = "updateBtn";
            this.updateBtn.Size = new System.Drawing.Size(75, 23);
            this.updateBtn.TabIndex = 39;
            this.updateBtn.Text = "Update";
            this.updateBtn.UseVisualStyleBackColor = true;
            // 
            // addNewBtn
            // 
            this.addNewBtn.Location = new System.Drawing.Point(352, 404);
            this.addNewBtn.Name = "addNewBtn";
            this.addNewBtn.Size = new System.Drawing.Size(75, 23);
            this.addNewBtn.TabIndex = 38;
            this.addNewBtn.Text = "Add New";
            this.addNewBtn.UseVisualStyleBackColor = true;
            this.addNewBtn.Click += new System.EventHandler(this.button4_Click);
            // 
            // backBtn
            // 
            this.backBtn.Location = new System.Drawing.Point(12, 612);
            this.backBtn.Name = "backBtn";
            this.backBtn.Size = new System.Drawing.Size(78, 29);
            this.backBtn.TabIndex = 37;
            this.backBtn.Text = "Back";
            this.backBtn.UseVisualStyleBackColor = true;
            this.backBtn.Click += new System.EventHandler(this.backBtn_Click);
            // 
            // logoutBtn
            // 
            this.logoutBtn.Location = new System.Drawing.Point(893, 12);
            this.logoutBtn.Name = "logoutBtn";
            this.logoutBtn.Size = new System.Drawing.Size(77, 33);
            this.logoutBtn.TabIndex = 36;
            this.logoutBtn.Text = "Logout";
            this.logoutBtn.UseVisualStyleBackColor = true;
            this.logoutBtn.Click += new System.EventHandler(this.logoutBtn_Click);
            // 
            // employeeAddressTB
            // 
            this.employeeAddressTB.Location = new System.Drawing.Point(433, 292);
            this.employeeAddressTB.Name = "employeeAddressTB";
            this.employeeAddressTB.Size = new System.Drawing.Size(139, 22);
            this.employeeAddressTB.TabIndex = 35;
            // 
            // employeePhnNoTB1
            // 
            this.employeePhnNoTB1.Location = new System.Drawing.Point(433, 264);
            this.employeePhnNoTB1.Name = "employeePhnNoTB1";
            this.employeePhnNoTB1.Size = new System.Drawing.Size(36, 22);
            this.employeePhnNoTB1.TabIndex = 33;
            // 
            // employeePhnNoTB2
            // 
            this.employeePhnNoTB2.Location = new System.Drawing.Point(475, 264);
            this.employeePhnNoTB2.Name = "employeePhnNoTB2";
            this.employeePhnNoTB2.Size = new System.Drawing.Size(97, 22);
            this.employeePhnNoTB2.TabIndex = 32;
            // 
            // employeeNameTB
            // 
            this.employeeNameTB.Location = new System.Drawing.Point(433, 236);
            this.employeeNameTB.Name = "employeeNameTB";
            this.employeeNameTB.Size = new System.Drawing.Size(139, 22);
            this.employeeNameTB.TabIndex = 31;
            // 
            // passTB
            // 
            this.passTB.Location = new System.Drawing.Point(433, 208);
            this.passTB.Name = "passTB";
            this.passTB.Size = new System.Drawing.Size(139, 22);
            this.passTB.TabIndex = 30;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(379, 353);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(48, 17);
            this.label6.TabIndex = 29;
            this.label6.Text = "Salary";
            // 
            // employeeIdTB
            // 
            this.employeeIdTB.Location = new System.Drawing.Point(433, 180);
            this.employeeIdTB.Name = "employeeIdTB";
            this.employeeIdTB.Size = new System.Drawing.Size(139, 22);
            this.employeeIdTB.TabIndex = 28;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(324, 318);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(103, 17);
            this.label5.TabIndex = 27;
            this.label5.Text = "Employee Role";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(367, 295);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(60, 17);
            this.label4.TabIndex = 26;
            this.label4.Text = "Address";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(316, 236);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(111, 17);
            this.label3.TabIndex = 25;
            this.label3.Text = "Employee Name";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(306, 267);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(121, 17);
            this.label2.TabIndex = 24;
            this.label2.Text = "Employee Phn No";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(340, 183);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(87, 17);
            this.label1.TabIndex = 23;
            this.label1.Text = "Employee ID";
            // 
            // employeeRoleCB
            // 
            this.employeeRoleCB.FormattingEnabled = true;
            this.employeeRoleCB.Items.AddRange(new object[] {
            "Manager",
            "General"});
            this.employeeRoleCB.Location = new System.Drawing.Point(433, 320);
            this.employeeRoleCB.Name = "employeeRoleCB";
            this.employeeRoleCB.Size = new System.Drawing.Size(139, 24);
            this.employeeRoleCB.TabIndex = 45;
            // 
            // deleteBtn
            // 
            this.deleteBtn.Location = new System.Drawing.Point(625, 404);
            this.deleteBtn.Name = "deleteBtn";
            this.deleteBtn.Size = new System.Drawing.Size(75, 23);
            this.deleteBtn.TabIndex = 46;
            this.deleteBtn.Text = "Delete";
            this.deleteBtn.UseVisualStyleBackColor = true;
            // 
            // autoGenerateIdBtn
            // 
            this.autoGenerateIdBtn.Location = new System.Drawing.Point(702, 179);
            this.autoGenerateIdBtn.Name = "autoGenerateIdBtn";
            this.autoGenerateIdBtn.Size = new System.Drawing.Size(130, 23);
            this.autoGenerateIdBtn.TabIndex = 47;
            this.autoGenerateIdBtn.Text = "Auto Generate ID";
            this.autoGenerateIdBtn.UseVisualStyleBackColor = true;
            this.autoGenerateIdBtn.Click += new System.EventHandler(this.autoGenerateIdBtn_Click);
            // 
            // AdminManageEmployee
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(982, 653);
            this.Controls.Add(this.autoGenerateIdBtn);
            this.Controls.Add(this.deleteBtn);
            this.Controls.Add(this.employeeRoleCB);
            this.Controls.Add(this.autoGeneratePassBtn);
            this.Controls.Add(this.employeeSalaryTB);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.loadBtn);
            this.Controls.Add(this.updateBtn);
            this.Controls.Add(this.addNewBtn);
            this.Controls.Add(this.backBtn);
            this.Controls.Add(this.logoutBtn);
            this.Controls.Add(this.employeeAddressTB);
            this.Controls.Add(this.employeePhnNoTB1);
            this.Controls.Add(this.employeePhnNoTB2);
            this.Controls.Add(this.employeeNameTB);
            this.Controls.Add(this.passTB);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.employeeIdTB);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "AdminManageEmployee";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "AdminManageEmployee";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.OwnerManageEmployee_FormClosing);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button autoGeneratePassBtn;
        private System.Windows.Forms.TextBox employeeSalaryTB;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Button loadBtn;
        private System.Windows.Forms.Button updateBtn;
        private System.Windows.Forms.Button addNewBtn;
        private System.Windows.Forms.Button backBtn;
        private System.Windows.Forms.Button logoutBtn;
        private System.Windows.Forms.TextBox employeeAddressTB;
        private System.Windows.Forms.TextBox employeePhnNoTB1;
        private System.Windows.Forms.TextBox employeePhnNoTB2;
        private System.Windows.Forms.TextBox employeeNameTB;
        private System.Windows.Forms.TextBox passTB;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox employeeIdTB;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ComboBox employeeRoleCB;
        private System.Windows.Forms.Button deleteBtn;
        private System.Windows.Forms.Button autoGenerateIdBtn;
    }
}