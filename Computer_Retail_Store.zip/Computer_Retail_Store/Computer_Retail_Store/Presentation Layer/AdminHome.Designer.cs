﻿namespace Computer_Retail_Store
{
    partial class AdminHome
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.logoutBtn = new System.Windows.Forms.Button();
            this.ownerInfoBtn = new System.Windows.Forms.Button();
            this.cngPassBtn = new System.Windows.Forms.Button();
            this.manageProductBtn = new System.Windows.Forms.Button();
            this.customerInfoBtn = new System.Windows.Forms.Button();
            this.manageEmployeeBtn = new System.Windows.Forms.Button();
            this.soldProductBtn = new System.Windows.Forms.Button();
            this.employeeListBtn = new System.Windows.Forms.Button();
            this.wlcmLabel = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // logoutBtn
            // 
            this.logoutBtn.Location = new System.Drawing.Point(890, 12);
            this.logoutBtn.Name = "logoutBtn";
            this.logoutBtn.Size = new System.Drawing.Size(80, 37);
            this.logoutBtn.TabIndex = 0;
            this.logoutBtn.Text = "Logout";
            this.logoutBtn.UseVisualStyleBackColor = true;
            this.logoutBtn.Click += new System.EventHandler(this.logoutBtn_Click);
            // 
            // ownerInfoBtn
            // 
            this.ownerInfoBtn.Location = new System.Drawing.Point(199, 189);
            this.ownerInfoBtn.Name = "ownerInfoBtn";
            this.ownerInfoBtn.Size = new System.Drawing.Size(221, 49);
            this.ownerInfoBtn.TabIndex = 2;
            this.ownerInfoBtn.Text = "My Info";
            this.ownerInfoBtn.UseVisualStyleBackColor = true;
            this.ownerInfoBtn.Click += new System.EventHandler(this.ownerInfoBtn_Click);
            // 
            // cngPassBtn
            // 
            this.cngPassBtn.Location = new System.Drawing.Point(199, 244);
            this.cngPassBtn.Name = "cngPassBtn";
            this.cngPassBtn.Size = new System.Drawing.Size(221, 49);
            this.cngPassBtn.TabIndex = 3;
            this.cngPassBtn.Text = "Change Password";
            this.cngPassBtn.UseVisualStyleBackColor = true;
            this.cngPassBtn.Click += new System.EventHandler(this.cngPassBtn_Click);
            // 
            // manageProductBtn
            // 
            this.manageProductBtn.Location = new System.Drawing.Point(538, 354);
            this.manageProductBtn.Name = "manageProductBtn";
            this.manageProductBtn.Size = new System.Drawing.Size(221, 49);
            this.manageProductBtn.TabIndex = 6;
            this.manageProductBtn.Text = "Manage Product";
            this.manageProductBtn.UseVisualStyleBackColor = true;
            this.manageProductBtn.Click += new System.EventHandler(this.manageProductBtn_Click);
            // 
            // customerInfoBtn
            // 
            this.customerInfoBtn.Location = new System.Drawing.Point(538, 189);
            this.customerInfoBtn.Name = "customerInfoBtn";
            this.customerInfoBtn.Size = new System.Drawing.Size(221, 49);
            this.customerInfoBtn.TabIndex = 7;
            this.customerInfoBtn.Text = "Customer Info";
            this.customerInfoBtn.UseVisualStyleBackColor = true;
            this.customerInfoBtn.Click += new System.EventHandler(this.customerInfoBtn_Click);
            // 
            // manageEmployeeBtn
            // 
            this.manageEmployeeBtn.Location = new System.Drawing.Point(538, 299);
            this.manageEmployeeBtn.Name = "manageEmployeeBtn";
            this.manageEmployeeBtn.Size = new System.Drawing.Size(221, 49);
            this.manageEmployeeBtn.TabIndex = 8;
            this.manageEmployeeBtn.Text = "Manage Employee";
            this.manageEmployeeBtn.UseVisualStyleBackColor = true;
            this.manageEmployeeBtn.Click += new System.EventHandler(this.button1_Click);
            // 
            // soldProductBtn
            // 
            this.soldProductBtn.Location = new System.Drawing.Point(538, 409);
            this.soldProductBtn.Name = "soldProductBtn";
            this.soldProductBtn.Size = new System.Drawing.Size(221, 49);
            this.soldProductBtn.TabIndex = 9;
            this.soldProductBtn.Text = "Sold Products";
            this.soldProductBtn.UseVisualStyleBackColor = true;
            this.soldProductBtn.Click += new System.EventHandler(this.soldProductBtn_Click);
            // 
            // employeeListBtn
            // 
            this.employeeListBtn.Location = new System.Drawing.Point(538, 244);
            this.employeeListBtn.Name = "employeeListBtn";
            this.employeeListBtn.Size = new System.Drawing.Size(221, 49);
            this.employeeListBtn.TabIndex = 10;
            this.employeeListBtn.Text = "Employee List";
            this.employeeListBtn.UseVisualStyleBackColor = true;
            this.employeeListBtn.Click += new System.EventHandler(this.employeeListBtn_Click);
            // 
            // wlcmLabel
            // 
            this.wlcmLabel.AutoSize = true;
            this.wlcmLabel.Location = new System.Drawing.Point(443, 48);
            this.wlcmLabel.Name = "wlcmLabel";
            this.wlcmLabel.Size = new System.Drawing.Size(46, 17);
            this.wlcmLabel.TabIndex = 11;
            this.wlcmLabel.Text = "label1";
            // 
            // AdminHome
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(982, 653);
            this.Controls.Add(this.wlcmLabel);
            this.Controls.Add(this.employeeListBtn);
            this.Controls.Add(this.soldProductBtn);
            this.Controls.Add(this.manageEmployeeBtn);
            this.Controls.Add(this.customerInfoBtn);
            this.Controls.Add(this.manageProductBtn);
            this.Controls.Add(this.cngPassBtn);
            this.Controls.Add(this.ownerInfoBtn);
            this.Controls.Add(this.logoutBtn);
            this.Name = "AdminHome";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "AdminHome";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.OwnerHome_FormClosing);
            this.Load += new System.EventHandler(this.AdminHome_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button logoutBtn;
        private System.Windows.Forms.Button ownerInfoBtn;
        private System.Windows.Forms.Button cngPassBtn;
        private System.Windows.Forms.Button manageProductBtn;
        private System.Windows.Forms.Button customerInfoBtn;
        private System.Windows.Forms.Button manageEmployeeBtn;
        private System.Windows.Forms.Button soldProductBtn;
        private System.Windows.Forms.Button employeeListBtn;
        private System.Windows.Forms.Label wlcmLabel;

    }
}