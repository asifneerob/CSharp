﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.SqlClient;
using Computer_Retail_Store.Business_Logic_Layer;

namespace Computer_Retail_Store.Data_Access_Layer
{
    class DataAccess
    {
        SqlConnection con;
        
        public DataAccess()
        {
            con = new SqlConnection(@"Data Source=DESKTOP-4JOONED;Initial Catalog=Computer_Retail_Store;Integrated Security=True");
            if (con.State == ConnectionState.Closed)
            {
                con.Open();
            }
        }

        public DataTable GetAllLogTypeInfo()
        {
            string query = string.Format("SELECT *FROM [haha].[dbo].[Login],[haha].[dbo].[types] where Login.typeId=types.id");
            SqlCommand cmd = new SqlCommand(query, con);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);
            con.Close();
            return dt;
        }

        LoginInfo l = new LoginInfo();
        public DataTable login(LoginInfo info)
        {

            string query = string.Format("select * from Login where userId='{0}' and password='{1}'", info.UserId, info.Password);
            SqlCommand cmd = new SqlCommand(query, con);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);
            con.Close();
            return dt;
        }
        public bool Insert(int id,string pass, int type)
        {
            //con.Open();
            string query = string.Format("INSERT INTO Login(userId,password,typeId) VALUES({0},'{1}',{2})",id,pass, type);
            SqlCommand cmd = new SqlCommand(query, con);
            int rows = -1;
            rows = cmd.ExecuteNonQuery();
            if (rows >= 0)
            {
                return true;
            }
            return false;
        }
        ~DataAccess()
        {
            if (con.State == ConnectionState.Open)
            {
              // con.Close();
            }
        }
    }
}
