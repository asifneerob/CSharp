﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Computer_Retail_Store.Data_Access_Layer;

namespace Computer_Retail_Store.Business_Logic_Layer
{
    class LogTypeInfo
    {
        public int UserId { get; set; }
        public string Password { get; set; }
        public string Type { get; set; }
        public int Typeid { get; set; }

        DataAccess da = new DataAccess();
        LogTypeInfo p;

        public List<LogTypeInfo> GetAllLogTyptInfo()
        {
            var Login = da.GetAllLogTypeInfo();
            List<LogTypeInfo> list = new List<LogTypeInfo>();
            for (int i = 0; i < Login.Rows.Count; i++)
            {
                p = new LogTypeInfo();
                p.UserId = int.Parse(Login.Rows[i][0].ToString());
                p.Password = Login.Rows[i][1].ToString();
                p.Type = Login.Rows[i][4].ToString();
                p.Typeid = int.Parse(Login.Rows[i][2].ToString());

                list.Add(p);
            }
            return list;
        }
        public bool CreatePerson(int id,string pass ,int type)
        {
            return da.Insert(id, pass, type);
        }
    }
}
